import express from "express";
import cors from "cors";
import crypto from "crypto";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || true }));
app.use(express.json());

app.get("/health", (_req,res) => res.json({ ok:true, service:"Divine Highest Authority payments" }));

// Paystack webhook endpoint.
// Configure this URL in Paystack Dashboard > Settings > API Keys & Webhooks.
// IMPORTANT: PAYSTACK_SECRET_KEY must be stored only as a server environment variable.
app.post("/api/paystack/webhook", express.raw({ type: "application/json" }), (req,res) => {
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return res.status(500).send("Payment server not configured");

  const signature = req.headers["x-paystack-signature"];
  const expected = crypto.createHmac("sha512", secret).update(req.body).digest("hex");
  if (!signature || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) {
    return res.status(401).send("Invalid signature");
  }

  const event = JSON.parse(req.body.toString("utf8"));
  if (event.event === "charge.success") {
    // Production step: persist the verified transaction/order in a database.
    // Digital delivery should be granted only after this verified event
    // and after validating amount, currency, product/order reference, etc.
    console.log("Verified Paystack payment:", event.data?.reference);
  }

  res.sendStatus(200);
});

app.post("/api/paystack/verify", async (req,res) => {
  const { reference } = req.body || {};
  if (!reference) return res.status(400).json({ error:"reference is required" });

  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return res.status(500).json({ error:"Payment server not configured" });

  const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
    headers: { Authorization: `Bearer ${secret}` }
  });

  const data = await response.json();
  if (!response.ok) return res.status(response.status).json(data);

  res.json(data);
});

const port = process.env.PORT || 10000;
app.listen(port, () => console.log(`DHA payment server listening on ${port}`));
