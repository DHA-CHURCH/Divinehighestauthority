import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const socials = {
  tiktok: "https://www.tiktok.com/@Divinehighestauthority.1",
  facebook: "https://www.facebook.com/",
  youtube: "https://www.youtube.com/@Prophetessflora4170",
  instagram: "https://www.instagram.com/Divinehighestauthority.1"
};

const givingOptions = [
  "Offering", "Tithe", "Prophet Offering", "Change a Life",
  "Kingdom Builders", "Seed of Faith", "Special Project Donation"
];

const storeItems = [
  { id:"audio", title:"Audio Sermons", text:"Listen and grow through selected ministry messages.", icon:"🎧" },
  { id:"video", title:"Video Teachings", text:"Watch deeper teachings designed for transformation.", icon:"▶" },
  { id:"courses", title:"Courses / Classes", text:"Learn, grow, and be equipped for Kingdom purpose.", icon:"🎓" },
  { id:"prayer", title:"Prayer & Declaration Packs", text:"Scripture-based prayer and declaration resources.", icon:"🙏" },
  { id:"devotional", title:"Devotionals", text:"Practical spiritual resources for daily growth.", icon:"📖" },
  { id:"replays", title:"Event Replays", text:"Receive selected conference and event replays.", icon:"🎥" }
];

const books = [
  { id:"book-1", title:"Featured Book", text:"Your first digital book will appear here.", price:"Add price", available:false }
];

function App() {
  const [page, setPage] = useState("home");
  const [giveType, setGiveType] = useState("Offering");
  const [amount, setAmount] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);

  const go = (p) => { setPage(p); setMenuOpen(false); window.scrollTo({top:0, behavior:"smooth"}); };

  const pageTitle = useMemo(() => ({
    home:"Encounter Jesus. Rise in Divine Authority.",
    about:"A Place of Encounter, Power, and Transformation in Christ",
    sermons:"Sermons & Livestreams",
    give:"Give & Partner With the Vision",
    books:"Book Library",
    store:"Ministry Store",
    contact:"Connect With Divine Highest Authority"
  }[page]), [page]);

  return (
    <div className="site">
      <header className="header">
        <div className="nav-wrap">
          <button className="brand" onClick={() => go("home")} aria-label="Divine Highest Authority home">
            <img src="/dha-logo.jpg" alt="Divine Highest Authority logo" />
            <div>
              <strong>DIVINE HIGHEST AUTHORITY</strong>
              <span>A Place of Encounter, Power, and Transformation in Christ.</span>
            </div>
          </button>
          <button className="menu-btn" onClick={() => setMenuOpen(v=>!v)} aria-label="Open menu">☰</button>
          <nav className={menuOpen ? "nav open" : "nav"}>
            {[
              ["home","Home"],["about","About"],["sermons","Sermons"],["give","Give"],
              ["books","Book Library"],["store","Store"],["contact","Contact"]
            ].map(([id,label]) => (
              <button key={id} className={page===id ? "active" : ""} onClick={() => go(id)}>{label}</button>
            ))}
            <button className="nav-cta" onClick={() => go("give")}>♥ Partner With Us</button>
          </nav>
        </div>
      </header>

      <main>
        {page === "home" && <Home go={go} />}
        {page === "about" && <About />}
        {page === "sermons" && <Sermons />}
        {page === "give" && <Give giveType={giveType} setGiveType={setGiveType} amount={amount} setAmount={setAmount} />}
        {page === "books" && <Books />}
        {page === "store" && <Store />}
        {page === "contact" && <Contact />}
      </main>

      <footer className="footer">
        <div className="footer-grid">
          <div>
            <img className="footer-logo" src="/dha-logo.jpg" alt="" />
            <h3>DIVINE HIGHEST AUTHORITY</h3>
            <p>A Place of Encounter, Power, and Transformation in Christ.</p>
            <div className="socials">
              <a href={socials.tiktok} target="_blank">TikTok</a>
              <a href={socials.instagram} target="_blank">Instagram</a>
              <a href={socials.youtube} target="_blank">YouTube</a>
              <a href={socials.facebook} target="_blank">Facebook</a>
            </div>
          </div>
          <div><h4>Quick Links</h4><button onClick={()=>go("about")}>About</button><button onClick={()=>go("sermons")}>Sermons</button><button onClick={()=>go("give")}>Give</button><button onClick={()=>go("books")}>Book Library</button><button onClick={()=>go("store")}>Store</button></div>
          <div><h4>Ministry</h4><p>Deliver the oppressed.</p><p>Revive the weary.</p><p>Equip believers to reign in life.</p><p>Walk in power, purity, purpose and love.</p></div>
          <div><h4>Contact</h4><p>📞 09124549061</p><p>✉ divinehighestauthority.111@gmail.com</p><p>📍 Lagos, Nigeria</p></div>
        </div>
        <div className="copyright">© {new Date().getFullYear()} Divine Highest Authority. All rights reserved. · Jesus Christ Himself is the Founder and the Highest Authority.</div>
      </footer>
    </div>
  );
}

function Home({go}) {
  return <section>
    <div className="hero">
      <div className="hero-copy">
        <div className="eyebrow">DIVINE HIGHEST AUTHORITY</div>
        <h1>Jesus Christ Himself Is Our <em>Founder and the Highest Authority.</em></h1>
        <p>We are a Holy Spirit–empowered ministry raising vessels of power, purity, and purpose for Kingdom impact.</p>
        <div className="actions"><button className="gold-btn" onClick={()=>go("sermons")}>▶ Watch Sermons</button><button className="outline-btn" onClick={()=>go("about")}>Our Mandate</button></div>
      </div>
      <div className="hero-art"><img src="/dha-logo.jpg" alt="Divine Highest Authority emblem" /></div>
    </div>

    <div className="pillars">
      <Pillar icon="▣" title="WORD" text="Teaching the uncompromised Word of God with revelation and power." />
      <Pillar icon="♨" title="WORSHIP" text="Encounter God in Spirit and Truth through worship." />
      <Pillar icon="✦" title="COMMUNITY" text="A family empowered to love, serve, and impact." />
      <Pillar icon="♛" title="KINGDOM IMPACT" text="Raising Kingdom builders for transformation." />
    </div>

    <section className="dark-band">
      <div className="section-heading"><span>GIVE AND</span> PARTNER WITH THE VISION</div>
      <p>Your giving supports the work of the ministry and helps us serve people through the Gospel.</p>
      <div className="give-mini">{givingOptions.map(x=><span key={x}>✦ {x}</span>)}</div>
      <button className="gold-btn" onClick={()=>go("give")}>Give Now</button>
    </section>

    <section className="content-section">
      <div className="center-title"><div className="eyebrow">GROW IN CHRIST</div><h2>MINISTRY STORE</h2><p>Equip yourself. Grow in faith. Walk in your calling.</p></div>
      <div className="store-grid">{storeItems.map(x=><article className="resource-card" key={x.id}><div className="resource-icon">{x.icon}</div><h3>{x.title}</h3><p>{x.text}</p></article>)}</div>
      <div className="center"><button className="gold-btn" onClick={()=>go("store")}>Visit Store</button></div>
    </section>
  </section>;
}

function Pillar({icon,title,text}) { return <div className="pillar"><div className="pillar-icon">{icon}</div><div><h3>{title}</h3><p>{text}</p></div></div>; }

function About() {
  return <section className="page-section"><PageHero title="Our Mandate" subtitle="Raising a generation that knows its identity, purpose, and authority in Christ." />
    <div className="two-col">
      <div><h2>Divine Highest Authority</h2><p>Divine Highest Authority — A Place of Encounter, Power, and Transformation in Christ was birthed by divine revelation — a heavenly assignment to raise a generation of believers who will walk in power, shine with divine light, and live transformed lives through Jesus Christ.</p><p>Through the fire of the Holy Spirit, this ministry is commissioned to bring deliverance to the bound, healing to the broken, and restoration to every destiny held captive.</p><p>We are raising vessels who know their identity in Christ, understand their purpose, and manifest the Kingdom with dominion and purity.</p></div>
      <div className="mandate-card"><div className="eyebrow">OUR MANDATE</div><h2>“To deliver the oppressed, revive the weary, and equip believers to reign in life through the power of the Holy Spirit.”</h2><p>Jesus Christ Himself is the Founder and the Highest Authority.</p></div>
    </div>
  </section>;
}

function Sermons() {
  return <section className="page-section"><PageHero title="Sermons & Livestreams" subtitle="Receive the Word, grow in Christ, and stay connected with the ministry." />
    <div className="social-grid">
      <SocialCard name="TikTok" handle="@Divinehighestauthority.1" url={socials.tiktok} text="Short teachings, prophetic encouragement and live updates." />
      <SocialCard name="YouTube" handle="@Prophetessflora4170" url={socials.youtube} text="Long-form sermons, teachings and ministry videos." />
      <SocialCard name="Facebook" handle="Chinwe Florence" url={socials.facebook} text="Connect with the ministry community and live sessions." />
      <SocialCard name="Instagram" handle="@Divinehighestauthority.1" url={socials.instagram} text="Ministry highlights, announcements and inspiration." />
    </div>
    <div className="notice"><strong>Livestreams:</strong> Our website is prepared to link directly to your live broadcasts. Exact livestream embeds can be added once the channel/page URLs are confirmed.</div>
  </section>;
}

function SocialCard({name,handle,url,text}) { return <article className="social-card"><div className="social-symbol">◎</div><h3>{name}</h3><strong>{handle}</strong><p>{text}</p><a className="gold-btn small" href={url} target="_blank">Visit {name}</a></article>; }

function Give({giveType,setGiveType,amount,setAmount}) {
  return <section className="page-section"><PageHero title="Give & Partner With the Vision" subtitle="Your generosity helps us serve people, share the Gospel, and advance the ministry." />
    <div className="give-layout">
      <div><h2>Choose a giving purpose</h2><div className="give-list">{givingOptions.map(x=><button key={x} className={giveType===x?"selected":""} onClick={()=>setGiveType(x)}>{x}</button>)}</div><div className="bank-card"><h3>Bank Transfer</h3><p><b>First Bank</b></p><p>Account Name: Ezeoke Chinwe Florence</p><p>Account Number: 3218620497</p><small>Online Paystack giving will be connected after the ministry Paystack account is created.</small></div></div>
      <div className="payment-card"><div className="eyebrow">SECURE ONLINE GIVING</div><h2>{giveType}</h2><label>Amount (NGN)</label><input value={amount} onChange={e=>setAmount(e.target.value)} placeholder="Enter amount" inputMode="numeric" /><button className="gold-btn" onClick={()=>alert("Paystack will be activated here after your Paystack account is connected.")}>Continue to Secure Payment</button><p className="tiny">Payments will be verified automatically through Paystack webhooks. Your Paystack secret key will never be placed in the public website.</p></div>
    </div>
  </section>;
}

function Books() {
  return <section className="page-section"><PageHero title="Book Library" subtitle="Books and digital publications to help you grow in Christ and live transformed." />
    <div className="books-grid">{books.map(b=><article className="book-card" key={b.id}><div className="book-cover"><img src="/dha-logo.jpg" alt="" /></div><h3>{b.title}</h3><p>{b.text}</p><strong>{b.price}</strong><button className="gold-btn" disabled={!b.available}>Add Your Book</button></article>)}</div>
    <div className="notice">Your book covers, titles, descriptions, prices and digital files can be added here. Once a book is connected to Paystack, successful payment can automatically unlock its digital download.</div>
  </section>;
}

function Store() {
  return <section className="page-section"><PageHero title="Ministry Store" subtitle="Digital resources designed to teach, equip, strengthen, and encourage believers." />
    <div className="store-grid large">{storeItems.map(x=><article className="resource-card store-detail" key={x.id}><div className="resource-icon">{x.icon}</div><h3>{x.title}</h3><p>{x.text}</p><button className="outline-btn" onClick={()=>alert("This product category is ready for products to be added.")}>Explore</button></article>)}</div>
    <div className="notice"><strong>Automated delivery:</strong> Digital resources will be delivered or unlocked after Paystack confirms a successful transaction.</div>
  </section>;
}

function Contact() {
  return <section className="page-section"><PageHero title="Connect With Us" subtitle="We are here to serve, pray, teach, and build with you." />
    <div className="contact-grid"><div className="contact-card"><h3>Divine Highest Authority</h3><p>📍 Lagos, Nigeria</p><p>📞 09124549061</p><p>✉ divinehighestauthority.111@gmail.com</p></div><div className="contact-card"><h3>Follow the Ministry</h3><p><a href={socials.tiktok} target="_blank">TikTok — Divinehighestauthority.1</a></p><p><a href={socials.youtube} target="_blank">YouTube — Prophetessflora4170</a></p><p><a href={socials.instagram} target="_blank">Instagram — Divinehighestauthority.1</a></p><p><a href={socials.facebook} target="_blank">Facebook — Chinwe Florence</a></p></div></div>
  </section>;
}

function PageHero({title,subtitle}) { return <div className="page-hero"><div className="eyebrow">DIVINE HIGHEST AUTHORITY</div><h1>{title}</h1><p>{subtitle}</p></div>; }

createRoot(document.getElementById("root")).render(<App />);
